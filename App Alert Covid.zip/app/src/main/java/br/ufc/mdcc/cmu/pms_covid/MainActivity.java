package br.ufc.mdcc.cmu.pms_covid;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.NotificationCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;

import br.ufc.mdcc.cmu.pmslib.PMS;
import br.ufc.mdcc.cmu.pmslib.PMSInterface;
import br.ufc.mdcc.cmu.pmslib.exception.PMSException;
import br.ufc.mdcc.cmu.pmslib.mqttbroker.MQTTProtocol;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private final String TAG = getClass().getSimpleName();
    private Button buttonStart;
    private TextView textViewResult;
    private TextView textViewDatetime;
    private TextView textViewGps;
    private TextView textViewDocDis;
    private TextView textViewNameDis;
    private TextView textViewIP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        buttonStart = (Button) findViewById(R.id.buttonStart);
        textViewResult = (TextView) findViewById(R.id.textViewResult);
        textViewDatetime = (TextView) findViewById(R.id.textViewDatetime);
        textViewGps = (TextView) findViewById(R.id.textViewGps);
        textViewDocDis = (TextView) findViewById(R.id.textViewNameDis);
        textViewNameDis = (TextView) findViewById(R.id.textViewDocDis);
        textViewIP = (TextView) findViewById(R.id.textViewIP);
        textViewResult.setText("Messages: ");

        buttonStart.setOnClickListener(this);

        readLocalData();
        verifyAlert();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    protected void onResume() {
        readLocalData();
        super.onResume();
    }

    private void startPMS(){
        PMSInterface pms = PMS.getInstance(this);
        pms.addCEPResourceClass(GPSCEPResource.class);
        try {
            pms.start();
            MQTTProtocol.getInstance(this).subscribe("/#", new SubscriberClientCallback());
            buttonStart.setEnabled(false);
            textViewResult.setText(textViewResult.getText().toString()+"\nPMS initialized successfully!\n");
        } catch (PMSException | MqttException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void readLocalData(){
        SharedPreferences sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
        String documentProfile = sharedPref.getString(getString(R.string.documentProfile), "");
        String nameProfile = sharedPref.getString(getString(R.string.nameProfile), "");

        if(!documentProfile.equals("")){
            textViewDocDis.setText("Doc.: "+documentProfile);
        }

        if(!nameProfile.equals("")){
            textViewNameDis.setText("Name: "+nameProfile);
        }

        String currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
        textViewDatetime.setText("Date: "+currentDate+"    Time: "+currentTime);

        textViewIP.setText("IPv4: "+Utils.getIPAddress(true));
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch (id){
            case R.id.buttonStart:
                startPMS();
                break;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.action_profile:
                Intent intent = new Intent(this, ProfileActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void verifyAlert(){
        new Thread(new Runnable() {
            public void run() {
                try {
                    Thread.sleep(180*1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                ConnectPMS.getInstance().getREST(MainActivity.this);
            }
        }).start();
    }

//    private void putRDF(){
//        String data = "PREFIX geo: <http://www.w3.org/2003/01/geo/wgs84_pos#>PREFIX " +
//                "foaf: <http://xmlns.com/foaf/0.1/>PREFIX " +
//                "pms: <http://www.pmsexample.com/>" +
//                "insert " +
//                "data{pms:22222222222 a foaf:Person. geo:Point222 a geo:LocalizationSensor; " +
//                "geo:long -38.57266310;geo:lat -3.7777777777;" +
//                "pms:day '2020-04-01';" +
//                "pms:time '13:01'. <http://purl.oclc.org/NET/UNIS/fiware/iot-lite#LocalizaionSensorID1122> a " +
//                "<http://purl.oclc.org/NET/ssnx/ssn#LocationSensor>;" +
//                "geo:location " +
//                "geo:Point222;" +
//                "pms:hasProprietary pms:22222222222.}";
//
//        ConnectPMS.getInstance().putREST(this, data);
//    }

    private class SubscriberClientCallback implements MqttCallback {
        private CountDownLatch m_latch = new CountDownLatch(1);

        void waitFinish() throws InterruptedException {
            m_latch.await();
        }

        @Override
        public void connectionLost(Throwable cause) {
            m_latch.countDown();
        }

        @Override
        public void messageArrived(final String topic, final MqttMessage message) throws Exception {
            Log.d(getClass().getSimpleName(), ">> Received message: "+message.toString()+" on topic "+topic);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    textViewResult.setText(textViewResult.getText().toString()+
                            "\nReceived message on topic: "+topic+" \nMessage:\n"+message.toString()+"\n");
                    ConnectPMS.getInstance().putREST(MainActivity.this, message.toString());
                }
            });
        }

        @Override
        public void deliveryComplete(IMqttDeliveryToken token) {

        }
    }

}