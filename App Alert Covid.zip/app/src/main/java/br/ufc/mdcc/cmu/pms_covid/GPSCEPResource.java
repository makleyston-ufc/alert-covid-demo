package br.ufc.mdcc.cmu.pms_covid;

import android.util.Log;

import br.ufc.mdcc.cmu.pmslib.cep.CEPResource;
import br.ufc.mdcc.cmu.pmslib.exception.SemanticAnnotationException;

public class GPSCEPResource extends CEPResource {

    private final String vocabulary = "http://www.w3.org/2003/01/geo/wgs84_pos/";
    public String lat;
    public String flag = "0";
    static private String lastLat;

    /*Begin - Getters and setters*/
    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }
    /*End - Getters and setters*/

    public GPSCEPResource(Object ontModel) {
        super(ontModel);
        try {
            setLat(getSemanticAnnotation().returnValuePropertyString(vocabulary, "lat"));

            if(lastLat != null)
                calcLat();

            lastLat = getLat();

        } catch (SemanticAnnotationException e) {
            e.printStackTrace();
        }
    }

    private void calcLat(){
        double lastLatDouble = Double.parseDouble(lastLat);
        double currentLatDouble = Double.parseDouble(getLat());

        //The user moved 50 meters.
        if(Math.abs(currentLatDouble - lastLatDouble) > 0.000050){
            setFlag("1");
        }else{
            setFlag("0");
        }

    }

    @Override
    public void configCEPResource(ConfigCEPResource configCEPResource) {
        configCEPResource.addTopic("/covid");
        configCEPResource.setType(vocabulary, "LocalizationSensor");
    }

    @Override
    public String getStatement() {
        Log.d("teste","aqui" );
        return "SELECT gps FROM GPSCEPResource AS gps WHERE gps.flag = '1'";

    }
}
