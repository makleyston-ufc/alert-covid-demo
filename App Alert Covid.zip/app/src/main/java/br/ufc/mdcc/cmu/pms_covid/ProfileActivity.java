package br.ufc.mdcc.cmu.pms_covid;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ProfileActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText editTextDoc;
    private EditText editTextName;
    private Button buttonRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        Toolbar toolbar = findViewById(R.id.toolbar_profile);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        editTextDoc = (EditText) findViewById(R.id.editTextDoc);
        editTextName = (EditText) findViewById(R.id.editTextName);
        buttonRegister = (Button) findViewById(R.id.buttonRegister);

        readProfile();

        buttonRegister.setOnClickListener(this);
    }

    private void registerProfile(){
        SharedPreferences sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString(getString(R.string.documentProfile), editTextDoc.getText().toString());
        editor.putString(getString(R.string.nameProfile), editTextName.getText().toString());
        editor.commit();

        Toast.makeText(this, "Profile saved successfully!", Toast.LENGTH_SHORT).show();
        onBackPressed();
    }

    private void readProfile(){
        SharedPreferences sharedPref = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);
        String documentProfile = sharedPref.getString(getString(R.string.documentProfile), "");
        String nameProfile = sharedPref.getString(getString(R.string.nameProfile), "");

        if(!documentProfile.equals("")){
            editTextDoc.setText(documentProfile);
        }else
            editTextDoc.requestFocus();

        if(!nameProfile.equals("")){
            editTextName.setText(nameProfile);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id){
            case R.id.buttonRegister:
                registerProfile();
                break;
        }
    }
}
