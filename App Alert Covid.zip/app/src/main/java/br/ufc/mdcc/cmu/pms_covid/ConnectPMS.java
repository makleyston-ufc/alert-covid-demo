package br.ufc.mdcc.cmu.pms_covid;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.StrictMode;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class ConnectPMS {


    final String address = "http://192.168.100.6";
    final String port = ":8080";
    final String uriInsert = "/PMS_Covid/webresources/Insert";

    final String TAG = getClass().getSimpleName();

    public static ConnectPMS instance = null;

    private ConnectPMS(){
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }

    public static ConnectPMS getInstance(){
        if(instance == null)
            instance = new ConnectPMS();
        return instance;
    }

    public void getREST(final Context context){

        SharedPreferences sharedPref = context.getSharedPreferences(context.getString(R.string.app_name), Context.MODE_PRIVATE);
        String documentProfile = sharedPref.getString(context.getString(R.string.documentProfile), "");

        RequestQueue mRequestQueue;
        StringRequest mStringRequest;
        mRequestQueue = Volley.newRequestQueue(context);
        String putUrl = address + port + uriInsert + "/" + documentProfile;

        mStringRequest = new StringRequest(Request.Method.GET, putUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //Log.d(TAG, ">> Response :" + response.toString());
                try {
                    JSONObject jsonObject = new JSONObject(response.toString());
                    String res = jsonObject.getString("hadContactWithAnInfectedPerson");
                    if(res.trim().equals("1")){
                        Notification notification = new Notification();
                        notification.pushNotification(context, "Atenção", "Você teve contato nos últimos 14 dias com uma pessoa diagnosticada com COVID-19. Fique atento aos sintomas e procure um médico caso algum sintoma seja percebido.");
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d(TAG,">> Error :" + error.toString());
            }
        });
        mRequestQueue.add(mStringRequest);
    }

    public void putREST(Context context, String data){

        String putUrl = address + port + uriInsert;
        RequestQueue requestQueue = Volley.newRequestQueue(context);

        JSONObject putData = new JSONObject();
        try {
            putData.put("script", data);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.PUT, putUrl, putData, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                System.out.println(response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        requestQueue.add(jsonObjectRequest);
    }
}
